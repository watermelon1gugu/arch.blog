module.exports = {
  // printWidth: 80,
  tabWidth: 2,
  // useTabs: false,
  semi: false,
  singleQuote: true
  // trailingComma: 'none',
  // bracketSpacing: true,
  // jsxBracketSameLine: false,
  // arrowParens: 'avoid',
  // rangeStart: 0,
  // rangeEnd: Infinity,
  // proseWrap: "preserve"
}